import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Image,
  TextInput,
  FlatList
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

// Placeholder data for featured cooks
const FEATURED_COOKS = [
  {
    id: '1',
    name: 'Mama Folake',
    image: 'https://via.placeholder.com/100',
    cuisine: 'Yoruba Cuisine',
    rating: 4.8,
    distance: '1.2km',
    dishes: 24,
  },
  {
    id: '2',
    name: 'Chef Emeka',
    image: 'https://via.placeholder.com/100',
    cuisine: 'Eastern Nigerian',
    rating: 4.9,
    distance: '2.3km',
    dishes: 36,
  },
  {
    id: '3',
    name: 'Auntie Bisi',
    image: 'https://via.placeholder.com/100',
    cuisine: 'Lagos Street Food',
    rating: 4.6,
    distance: '0.8km',
    dishes: 18,
  },
  {
    id: '4',
    name: 'Mallam Hassan',
    image: 'https://via.placeholder.com/100',
    cuisine: 'Northern Nigerian',
    rating: 4.7,
    distance: '3.1km',
    dishes: 22,
  },
];

// Placeholder data for trending dishes
const TRENDING_DISHES = [
  {
    id: '1',
    name: 'Jollof Rice Special',
    image: 'https://via.placeholder.com/150',
    cookName: 'Mama Folake',
    price: '₦1,800',
    rating: 4.9,
    likes: 320,
  },
  {
    id: '2',
    name: 'Egusi Soup with Pounded Yam',
    image: 'https://via.placeholder.com/150',
    cookName: 'Chef Emeka',
    price: '₦2,200',
    rating: 4.8,
    likes: 285,
  },
  {
    id: '3',
    name: 'Asun (Spicy Goat Meat)',
    image: 'https://via.placeholder.com/150',
    cookName: 'Auntie Bisi',
    price: '₦2,500',
    rating: 4.7,
    likes: 245,
  },
  {
    id: '4',
    name: 'Suya Platter',
    image: 'https://via.placeholder.com/150',
    cookName: 'Mallam Hassan',
    price: '₦1,900',
    rating: 4.6,
    likes: 198,
  },
];

// Placeholder data for recommended dishes
const RECOMMENDED_DISHES = [
  {
    id: '1',
    name: 'Ofada Rice with Stew',
    image: 'https://via.placeholder.com/150',
    cookName: 'Chef James',
    price: '₦1,700',
    rating: 4.5,
  },
  {
    id: '2',
    name: 'Efo Riro with Beef',
    image: 'https://via.placeholder.com/150',
    cookName: 'Mama Bola',
    price: '₦1,600',
    rating: 4.6,
  },
  {
    id: '3',
    name: 'Fried Rice & Chicken',
    image: 'https://via.placeholder.com/150',
    cookName: 'Chef Tunde',
    price: '₦2,100',
    rating: 4.7,
  },
  {
    id: '4',
    name: 'Peppersoup (Catfish)',
    image: 'https://via.placeholder.com/150',
    cookName: 'Mama Joy',
    price: '₦2,300',
    rating: 4.8,
  },
];

// Placeholder data for cuisines
const CUISINES = [
  { id: '1', name: 'Yoruba', icon: 'restaurant-outline' },
  { id: '2', name: 'Igbo', icon: 'fast-food-outline' },
  { id: '3', name: 'Hausa', icon: 'pizza-outline' },
  { id: '4', name: 'Efik/Calabar', icon: 'cafe-outline' },
  { id: '5', name: 'Continental', icon: 'wine-outline' },
  { id: '6', name: 'Snacks', icon: 'ice-cream-outline' },
];

const ExploreScreen = () => {
  const [searchText, setSearchText] = useState('');

  const renderCookItem = ({ item }) => (
    <TouchableOpacity style={styles.cookCard}>
      <Image source={{ uri: item.image }} style={styles.cookImage} />
      <View style={styles.cookInfo}>
        <Text style={styles.cookName}>{item.name}</Text>
        <Text style={styles.cookCuisine}>{item.cuisine}</Text>
        
        <View style={styles.cookMetaContainer}>
          <View style={styles.cookMetaItem}>
            <Ionicons name="star" size={16} color="#FFD700" />
            <Text style={styles.cookMetaText}>{item.rating}</Text>
          </View>
          
          <View style={styles.cookMetaItem}>
            <Ionicons name="location" size={16} color="#F57C00" />
            <Text style={styles.cookMetaText}>{item.distance}</Text>
          </View>
          
          <View style={styles.cookMetaItem}>
            <Ionicons name="restaurant" size={16} color="#4CAF50" />
            <Text style={styles.cookMetaText}>{item.dishes} dishes</Text>
          </View>
        </View>
        
        <TouchableOpacity style={styles.followButton}>
          <Text style={styles.followButtonText}>Follow</Text>
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );

  const renderTrendingDishItem = ({ item }) => (
    <TouchableOpacity style={styles.trendingDishCard}>
      <Image source={{ uri: item.image }} style={styles.trendingDishImage} />
      
      <View style={styles.trendingDishOverlay}>
        <View style={styles.trendingDishBadge}>
          <Ionicons name="trending-up" size={12} color="#fff" />
          <Text style={styles.trendingDishBadgeText}>Trending</Text>
        </View>
      </View>
      
      <View style={styles.trendingDishInfo}>
        <Text style={styles.trendingDishName} numberOfLines={1}>{item.name}</Text>
        <Text style={styles.trendingDishCook} numberOfLines={1}>By {item.cookName}</Text>
        
        <View style={styles.trendingDishMeta}>
          <View style={styles.trendingDishRating}>
            <Ionicons name="star" size={14} color="#FFD700" />
            <Text style={styles.trendingDishRatingText}>{item.rating}</Text>
          </View>
          
          <Text style={styles.trendingDishPrice}>{item.price}</Text>
        </View>
        
        <View style={styles.trendingDishActions}>
          <TouchableOpacity style={styles.trendingDishLikeButton}>
            <Ionicons name="heart-outline" size={20} color="#F57C00" />
            <Text style={styles.trendingDishLikeText}>{item.likes}</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.trendingDishOrderButton}>
            <Text style={styles.trendingDishOrderText}>Order</Text>
          </TouchableOpacity>
        </View>
      </View>
    </TouchableOpacity>
  );

  const renderRecommendedDishItem = ({ item }) => (
    <TouchableOpacity style={styles.recommendedDishCard}>
      <Image source={{ uri: item.image }} style={styles.recommendedDishImage} />
      
      <View style={styles.recommendedDishInfo}>
        <Text style={styles.recommendedDishName} numberOfLines={2}>{item.name}</Text>
        <Text style={styles.recommendedDishCook} numberOfLines={1}>By {item.cookName}</Text>
        
        <View style={styles.recommendedDishMeta}>
          <View style={styles.recommendedDishRating}>
            <Ionicons name="star" size={14} color="#FFD700" />
            <Text style={styles.recommendedDishRatingText}>{item.rating}</Text>
          </View>
          
          <Text style={styles.recommendedDishPrice}>{item.price}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  const renderCuisineItem = ({ item }) => (
    <TouchableOpacity style={styles.cuisineButton}>
      <View style={styles.cuisineIconContainer}>
        <Ionicons name={item.icon} size={24} color="#F57C00" />
      </View>
      <Text style={styles.cuisineName}>{item.name}</Text>
    </TouchableOpacity>
  );

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Search Bar */}
      <View style={styles.searchContainer}>
        <View style={styles.searchBar}>
          <Ionicons name="search" size={20} color="#666" />
          <TextInput
            style={styles.searchInput}
            placeholder="Search dishes, cooks, cuisines..."
            value={searchText}
            onChangeText={setSearchText}
          />
          {searchText.length > 0 && (
            <TouchableOpacity onPress={() => setSearchText('')}>
              <Ionicons name="close-circle" size={20} color="#666" />
            </TouchableOpacity>
          )}
        </View>
        
        <TouchableOpacity style={styles.filterButton}>
          <Ionicons name="options-outline" size={20} color="#F57C00" />
        </TouchableOpacity>
      </View>

      {/* Cuisines Section */}
      <View style={styles.sectionContainer}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Explore Cuisines</Text>
          <TouchableOpacity>
            <Text style={styles.seeAllText}>See All</Text>
          </TouchableOpacity>
        </View>
        
        <FlatList
          data={CUISINES}
          renderItem={renderCuisineItem}
          keyExtractor={item => item.id}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.cuisineList}
        />
      </View>

      {/* Featured Cooks Section */}
      <View style={styles.sectionContainer}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Featured Cooks</Text>
          <TouchableOpacity>
            <Text style={styles.seeAllText}>See All</Text>
          </TouchableOpacity>
        </View>
        
        <FlatList
          data={FEATURED_COOKS}
          renderItem={renderCookItem}
          keyExtractor={item => item.id}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.cooksList}
        />
      </View>

      {/* Trending Dishes Section */}
      <View style={styles.sectionContainer}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Trending Dishes</Text>
          <TouchableOpacity>
            <Text style={styles.seeAllText}>See All</Text>
          </TouchableOpacity>
        </View>
        
        <FlatList
          data={TRENDING_DISHES}
          renderItem={renderTrendingDishItem}
          keyExtractor={item => item.id}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.trendingDishesList}
        />
      </View>

      {/* Recommended Dishes Section */}
      <View style={[styles.sectionContainer, { marginBottom: 30 }]}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Recommended For You</Text>
          <TouchableOpacity>
            <Text style={styles.seeAllText}>See All</Text>
          </TouchableOpacity>
        </View>
        
        <View style={styles.recommendedDishesGrid}>
          {RECOMMENDED_DISHES.map(item => (
            <View key={item.id} style={styles.recommendedDishContainer}>
              {renderRecommendedDishItem({ item })}
            </View>
          ))}
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f8f8',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#fff',
  },
  searchBar: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f0f0f0',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    marginRight: 10,
  },
  searchInput: {
    flex: 1,
    marginLeft: 8,
    fontSize: 16,
    color: '#333',
  },
  filterButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f0f0',
    borderRadius: 8,
  },
  sectionContainer: {
    marginTop: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  seeAllText: {
    fontSize: 14,
    color: '#F57C00',
  },
  cuisineList: {
    paddingHorizontal: 16,
  },
  cuisineButton: {
    alignItems: 'center',
    marginRight: 20,
    width: 70,
  },
  cuisineIconContainer: {
    width: 60,
    height: 60,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 30,
    marginBottom: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  cuisineName: {
    fontSize: 14,
    color: '#333',
    textAlign: 'center',
  },
  cooksList: {
    paddingHorizontal: 16,
  },
  cookCard: {
    width: 280,
    backgroundColor: '#fff',
    borderRadius: 10,
    marginRight: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
    overflow: 'hidden',
  },
  cookImage: {
    width: '100%',
    height: 120,
    resizeMode: 'cover',
  },
  cookInfo: {
    padding: 12,
  },
  cookName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  cookCuisine: {
    fontSize: 14,
    color: '#666',
    marginTop: 2,
  },
  cookMetaContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
    marginBottom: 12,
  },
  cookMetaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 12,
  },
  cookMetaText: {
    fontSize: 13,
    color: '#666',
    marginLeft: 4,
  },
  followButton: {
    backgroundColor: '#F57C00',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 20,
    alignSelf: 'flex-start',
  },
  followButtonText: {
    color: '#fff',
    fontWeight: '500',
    fontSize: 14,
  },
  trendingDishesList: {
    paddingHorizontal: 16,
  },
  trendingDishCard: {
    width: 220,
    backgroundColor: '#fff',
    borderRadius: 10,
    marginRight: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
    overflow: 'hidden',
  },
  trendingDishImage: {
    width: '100%',
    height: 140,
    resizeMode: 'cover',
  },
  trendingDishOverlay: {
    position: 'absolute',
    top: 10,
    left: 10,
  },
  trendingDishBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F57C00',
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 12,
  },
  trendingDishBadgeText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '500',
    marginLeft: 4,
  },
  trendingDishInfo: {
    padding: 12,
  },
  trendingDishName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  trendingDishCook: {
    fontSize: 14,
    color: '#666',
    marginTop: 2,
  },
  trendingDishMeta: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 8,
  },
  trendingDishRating: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  trendingDishRatingText: {
    fontSize: 14,
    color: '#666',
    marginLeft: 4,
  },
  trendingDishPrice: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#F57C00',
  },
  trendingDishActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 12,
  },
  trendingDishLikeButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  trendingDishLikeText: {
    fontSize: 14,
    color: '#666',
    marginLeft: 4,
  },
  trendingDishOrderButton: {
    backgroundColor: '#F57C00',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 15,
  },
  trendingDishOrderText: {
    color: '#fff',
    fontWeight: '500',
    fontSize: 13,
  },
  recommendedDishesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
  },
  recommendedDishContainer: {
    width: '48%',
    marginBottom: 15,
  },
  recommendedDishCard: {
    backgroundColor: '#fff',
    borderRadius: 10,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
    height: 230,
  },
  recommendedDishImage: {
    width: '100%',
    height: 140,
    resizeMode: 'cover',
  },
  recommendedDishInfo: {
    padding: 10,
  },
  recommendedDishName: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 4,
    height: 36,
  },
  recommendedDishCook: {
    fontSize: 13,
    color: '#666',
  },
  recommendedDishMeta: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 8,
  },
  recommendedDishRating: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  recommendedDishRatingText: {
    fontSize: 13,
    color: '#666',
    marginLeft: 4,
  },
  recommendedDishPrice: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#F57C00',
  },
});

export default ExploreScreen;