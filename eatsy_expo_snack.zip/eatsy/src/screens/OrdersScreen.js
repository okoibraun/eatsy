import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  Image,
  ActivityIndicator,
  RefreshControl
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { authService } from '../services/api';

// Placeholder order data - in production, this would come from the API
const ORDERS_DATA = {
  active: [
    {
      id: '1',
      cookName: 'Mama Folake',
      cookImage: 'https://via.placeholder.com/50',
      status: 'Preparing',
      totalAmount: '₦3,200',
      deliveryFee: '₦500',
      orderDate: '2023-11-10T15:30:00',
      items: [
        {
          id: '1',
          name: 'Jollof Rice with Chicken',
          quantity: 2,
          price: '₦1,500',
          image: 'https://via.placeholder.com/60'
        }
      ]
    },
    {
      id: '2',
      cookName: 'Chef Emeka',
      cookImage: 'https://via.placeholder.com/50',
      status: 'On the way',
      totalAmount: '₦4,500',
      deliveryFee: '₦700',
      orderDate: '2023-11-10T14:15:00',
      items: [
        {
          id: '1',
          name: 'Egusi Soup with Pounded Yam',
          quantity: 1,
          price: '₦2,300',
          image: 'https://via.placeholder.com/60'
        },
        {
          id: '2',
          name: 'Moin Moin',
          quantity: 2,
          price: '₦800',
          image: 'https://via.placeholder.com/60'
        }
      ]
    }
  ],
  past: [
    {
      id: '3',
      cookName: 'Auntie Bisi',
      cookImage: 'https://via.placeholder.com/50',
      status: 'Delivered',
      totalAmount: '₦2,800',
      deliveryFee: '₦500',
      orderDate: '2023-11-08T12:45:00',
      items: [
        {
          id: '1',
          name: 'Ofada Rice with Stew',
          quantity: 1,
          price: '₦1,800',
          image: 'https://via.placeholder.com/60'
        },
        {
          id: '2',
          name: 'Moi Moi',
          quantity: 1,
          price: '₦500',
          image: 'https://via.placeholder.com/60'
        }
      ]
    },
    {
      id: '4',
      cookName: 'Mallam Hassan',
      cookImage: 'https://via.placeholder.com/50',
      status: 'Delivered',
      totalAmount: '₦3,600',
      deliveryFee: '₦600',
      orderDate: '2023-11-06T18:20:00',
      items: [
        {
          id: '1',
          name: 'Suya Platter (Beef)',
          quantity: 2,
          price: '₦1,500',
          image: 'https://via.placeholder.com/60'
        }
      ]
    },
    {
      id: '5',
      cookName: 'Chef James',
      cookImage: 'https://via.placeholder.com/50',
      status: 'Delivered',
      totalAmount: '₦5,200',
      deliveryFee: '₦700',
      orderDate: '2023-11-03T19:35:00',
      items: [
        {
          id: '1',
          name: 'Pepper Soup (Goat)',
          quantity: 1,
          price: '₦2,200',
          image: 'https://via.placeholder.com/60'
        },
        {
          id: '2',
          name: 'Fried Rice with Chicken',
          quantity: 1,
          price: '₦2,300',
          image: 'https://via.placeholder.com/60'
        }
      ]
    }
  ]
};

const OrdersScreen = () => {
  const [activeTab, setActiveTab] = useState('active');
  const [orders, setOrders] = useState(ORDERS_DATA);
  const [isLoading, setIsLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // Format date to readable format
  const formatDate = (dateStr) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-NG', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Get status color based on order status
  const getStatusColor = (status) => {
    switch (status) {
      case 'Pending':
        return '#F57C00'; // Orange
      case 'Confirmed':
        return '#0288D1'; // Blue
      case 'Preparing':
        return '#8BC34A'; // Light Green
      case 'Ready':
        return '#FF9800'; // Amber
      case 'On the way':
        return '#673AB7'; // Deep Purple
      case 'Delivered':
        return '#4CAF50'; // Green
      case 'Cancelled':
        return '#F44336'; // Red
      default:
        return '#9E9E9E'; // Grey
    }
  };

  // Fetch orders from API
  const fetchOrders = async () => {
    setIsLoading(true);
    try {
      // In a real app, we would make an API call here
      // const response = await api.get('/orders');
      // setOrders(response.data);
      
      // Using placeholder data for now
      setOrders(ORDERS_DATA);
    } catch (error) {
      console.error('Error fetching orders:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const onRefresh = async () => {
    setRefreshing(true);
    await fetchOrders();
    setRefreshing(false);
  };

  const renderOrderItem = ({ item }) => (
    <View style={styles.orderCard}>
      <View style={styles.orderHeader}>
        <View style={styles.cookInfo}>
          <Image source={{ uri: item.cookImage }} style={styles.cookImage} />
          <Text style={styles.cookName}>{item.cookName}</Text>
        </View>
        <View style={styles.orderInfo}>
          <Text style={[styles.statusText, { color: getStatusColor(item.status) }]}>
            {item.status}
          </Text>
          <Text style={styles.orderDate}>{formatDate(item.orderDate)}</Text>
        </View>
      </View>

      <View style={styles.divider} />

      <FlatList
        data={item.items}
        keyExtractor={(orderItem) => orderItem.id}
        scrollEnabled={false}
        renderItem={({ item: orderItem }) => (
          <View style={styles.orderItem}>
            <Image source={{ uri: orderItem.image }} style={styles.orderItemImage} />
            <View style={styles.orderItemInfo}>
              <Text style={styles.orderItemName}>{orderItem.name}</Text>
              <Text style={styles.orderItemPrice}>
                {orderItem.price} x {orderItem.quantity}
              </Text>
            </View>
          </View>
        )}
      />

      <View style={styles.divider} />

      <View style={styles.orderFooter}>
        <View style={styles.orderTotals}>
          <Text style={styles.orderTotalLabel}>Total:</Text>
          <Text style={styles.orderTotalValue}>{item.totalAmount}</Text>
        </View>

        <View style={styles.orderActions}>
          {activeTab === 'active' ? (
            <>
              <TouchableOpacity style={styles.orderActionButton}>
                <Ionicons name="call-outline" size={18} color="#F57C00" />
                <Text style={styles.orderActionText}>Call</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.orderActionButton}>
                <Ionicons name="chatbubble-outline" size={18} color="#F57C00" />
                <Text style={styles.orderActionText}>Chat</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.orderTrackButton}>
                <Text style={styles.orderTrackButtonText}>Track Order</Text>
              </TouchableOpacity>
            </>
          ) : (
            <>
              <TouchableOpacity style={styles.orderActionButton}>
                <Ionicons name="star-outline" size={18} color="#F57C00" />
                <Text style={styles.orderActionText}>Rate</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.orderReorderButton}>
                <Text style={styles.orderReorderButtonText}>Reorder</Text>
              </TouchableOpacity>
            </>
          )}
        </View>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      {/* Tab Toggle */}
      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[
            styles.tabButton,
            activeTab === 'active' && styles.activeTabButton
          ]}
          onPress={() => setActiveTab('active')}
        >
          <Text
            style={[
              styles.tabButtonText,
              activeTab === 'active' && styles.activeTabButtonText
            ]}
          >
            Active Orders
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[
            styles.tabButton,
            activeTab === 'past' && styles.activeTabButton
          ]}
          onPress={() => setActiveTab('past')}
        >
          <Text
            style={[
              styles.tabButtonText,
              activeTab === 'past' && styles.activeTabButtonText
            ]}
          >
            Order History
          </Text>
        </TouchableOpacity>
      </View>

      {isLoading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#F57C00" />
        </View>
      ) : (
        <FlatList
          data={activeTab === 'active' ? orders.active : orders.past}
          keyExtractor={(item) => item.id}
          renderItem={renderOrderItem}
          contentContainerStyle={styles.ordersList}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              colors={['#F57C00']}
            />
          }
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Ionicons name="fast-food-outline" size={80} color="#ccc" />
              <Text style={styles.emptyText}>
                {activeTab === 'active'
                  ? "You don't have any active orders"
                  : "You haven't placed any orders yet"}
              </Text>
              {activeTab === 'past' && (
                <TouchableOpacity style={styles.exploreButton}>
                  <Text style={styles.exploreButtonText}>Explore Dishes</Text>
                </TouchableOpacity>
              )}
            </View>
          }
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f8f8',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  tabButton: {
    flex: 1,
    paddingVertical: 10,
    alignItems: 'center',
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  activeTabButton: {
    borderBottomColor: '#F57C00',
  },
  tabButtonText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#666',
  },
  activeTabButtonText: {
    color: '#F57C00',
  },
  ordersList: {
    padding: 15,
  },
  orderCard: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  orderHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  cookInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  cookImage: {
    width: 30,
    height: 30,
    borderRadius: 15,
    marginRight: 8,
  },
  cookName: {
    fontSize: 16,
    fontWeight: '500',
    color: '#333',
  },
  orderInfo: {
    alignItems: 'flex-end',
  },
  statusText: {
    fontSize: 14,
    fontWeight: '500',
  },
  orderDate: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
  divider: {
    height: 1,
    backgroundColor: '#eee',
    marginVertical: 10,
  },
  orderItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  orderItemImage: {
    width: 40,
    height: 40,
    borderRadius: 6,
    marginRight: 10,
  },
  orderItemInfo: {
    flex: 1,
  },
  orderItemName: {
    fontSize: 14,
    color: '#333',
  },
  orderItemPrice: {
    fontSize: 13,
    color: '#666',
    marginTop: 2,
  },
  orderFooter: {
    marginTop: 5,
  },
  orderTotals: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15,
  },
  orderTotalLabel: {
    fontSize: 16,
    color: '#333',
    fontWeight: '500',
  },
  orderTotalValue: {
    fontSize: 16,
    color: '#F57C00',
    fontWeight: 'bold',
  },
  orderActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  orderActionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 15,
  },
  orderActionText: {
    marginLeft: 4,
    color: '#F57C00',
    fontSize: 14,
  },
  orderTrackButton: {
    backgroundColor: '#F57C00',
    paddingVertical: 8,
    paddingHorizontal: 15,
    borderRadius: 20,
  },
  orderTrackButtonText: {
    color: '#fff',
    fontWeight: '500',
    fontSize: 14,
  },
  orderReorderButton: {
    backgroundColor: '#F57C00',
    paddingVertical: 8,
    paddingHorizontal: 15,
    borderRadius: 20,
  },
  orderReorderButtonText: {
    color: '#fff',
    fontWeight: '500',
    fontSize: 14,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: 50,
  },
  emptyText: {
    fontSize: 16,
    color: '#666',
    marginTop: 10,
    marginBottom: 20,
    textAlign: 'center',
  },
  exploreButton: {
    backgroundColor: '#F57C00',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 25,
  },
  exploreButtonText: {
    color: '#fff',
    fontWeight: '500',
    fontSize: 16,
  },
});

export default OrdersScreen;