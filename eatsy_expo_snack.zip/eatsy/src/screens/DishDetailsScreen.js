import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Share,
  Dimensions
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { api } from '../services/api';
import EatsyButton from '../components/common/EatsyButton';

const { width } = Dimensions.get('window');

/**
 * DishDetailsScreen - Shows complete details of a specific dish
 * 
 * @param {Object} route - Route parameters containing dishId
 * @param {Object} navigation - Navigation object
 * @returns {JSX.Element} Dish details screen
 */
const DishDetailsScreen = ({ route, navigation }) => {
  const { dishId } = route.params;
  const [dish, setDish] = useState(null);
  const [cook, setCook] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isLiked, setIsLiked] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [selectedTag, setSelectedTag] = useState(null);

  useEffect(() => {
    fetchDishDetails();
  }, [dishId]);

  const fetchDishDetails = async () => {
    setIsLoading(true);
    setError(null);

    try {
      // In a real app, make a single API call that returns dish with cook info
      const response = await api.get(`/api/v1/dishes/${dishId}`);
      if (response.data && response.data.success) {
        setDish(response.data.data.dish);
        setCook(response.data.data.cook);
        setIsLiked(response.data.data.isLiked);
        setIsSaved(response.data.data.isSaved);
      } else {
        setError('Failed to load dish details');
      }
    } catch (err) {
      console.error('Error fetching dish details:', err);
      setError('An error occurred while fetching dish details');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddToCart = async () => {
    try {
      const response = await api.post('/api/v1/orders/add-item', {
        dishId,
        quantity
      });

      if (response.data && response.data.success) {
        // Show success message
        // In a real app, you might display a toast notification
        navigation.navigate('Cart');
      } else {
        // Handle error
        console.error('Failed to add to cart');
      }
    } catch (err) {
      console.error('Error adding to cart:', err);
    }
  };

  const handleBuyNow = async () => {
    try {
      const response = await api.post('/api/v1/orders/add-item', {
        dishId,
        quantity
      });

      if (response.data && response.data.success) {
        // Navigate directly to checkout
        navigation.navigate('Checkout');
      } else {
        // Handle error
        console.error('Failed to process order');
      }
    } catch (err) {
      console.error('Error processing order:', err);
    }
  };

  const handleToggleLike = async () => {
    try {
      const response = await api.post(`/api/v1/dishes/${dishId}/toggle-like`);
      if (response.data && response.data.success) {
        setIsLiked(response.data.data.isLiked);
      }
    } catch (err) {
      console.error('Error toggling like:', err);
    }
  };

  const handleToggleSave = async () => {
    try {
      const response = await api.post(`/api/v1/dishes/${dishId}/toggle-save`);
      if (response.data && response.data.success) {
        setIsSaved(response.data.data.isSaved);
      }
    } catch (err) {
      console.error('Error toggling save:', err);
    }
  };

  const handleShare = async () => {
    if (!dish) return;

    try {
      await Share.share({
        message: `Check out this delicious ${dish.name} by ${cook.fullName} on Eatsy Nigeria!`,
        url: `https://eatsy.ng/dishes/${dishId}`,
        title: `${dish.name} on Eatsy Nigeria`,
      });
    } catch (error) {
      console.error('Error sharing dish:', error);
    }
  };

  const increaseQuantity = () => {
    setQuantity(prevQuantity => prevQuantity + 1);
  };

  const decreaseQuantity = () => {
    setQuantity(prevQuantity => Math.max(1, prevQuantity - 1));
  };

  const goToCookProfile = () => {
    navigation.navigate('CookProfile', { cookId: cook.id });
  };

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#F57C00" />
        <Text style={styles.loadingText}>Loading dish details...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.errorContainer}>
        <Ionicons name="alert-circle-outline" size={64} color="#F57C00" />
        <Text style={styles.errorText}>{error}</Text>
        <EatsyButton 
          label="Try Again" 
          onPress={fetchDishDetails}
          style={{ marginTop: 20 }}
        />
      </View>
    );
  }

  if (!dish || !cook) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>Dish not found</Text>
        <EatsyButton 
          label="Go Back" 
          onPress={() => navigation.goBack()}
          style={{ marginTop: 20 }}
        />
      </View>
    );
  }

  const calculateTotalPrice = () => {
    let basePrice = dish.price;
    if (dish.originalPrice && dish.originalPrice > dish.price) {
      basePrice = dish.price;
    }
    return basePrice * quantity;
  };

  return (
    <View style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Dish Image */}
        <View style={styles.imageContainer}>
          <Image 
            source={{ uri: dish.imageUrl }} 
            style={styles.dishImage} 
            resizeMode="cover"
          />
          
          <TouchableOpacity 
            style={styles.backButton}
            onPress={() => navigation.goBack()}
          >
            <Ionicons name="arrow-back" size={24} color="#FFF" />
          </TouchableOpacity>
          
          <View style={styles.imageActions}>
            <TouchableOpacity 
              style={styles.actionButton}
              onPress={handleToggleLike}
            >
              <Ionicons 
                name={isLiked ? "heart" : "heart-outline"} 
                size={24} 
                color={isLiked ? "#F44336" : "#FFF"} 
              />
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.actionButton}
              onPress={handleToggleSave}
            >
              <Ionicons 
                name={isSaved ? "bookmark" : "bookmark-outline"} 
                size={24} 
                color={isSaved ? "#F57C00" : "#FFF"} 
              />
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.actionButton}
              onPress={handleShare}
            >
              <Ionicons name="share-outline" size={24} color="#FFF" />
            </TouchableOpacity>
          </View>
        </View>
        
        {/* Dish Info */}
        <View style={styles.infoContainer}>
          <View style={styles.headerContainer}>
            <View style={styles.titleContainer}>
              <Text style={styles.dishName}>{dish.name}</Text>
              
              <View style={styles.ratingContainer}>
                <Ionicons name="star" size={16} color="#FFD700" />
                <Text style={styles.ratingText}>
                  {dish.rating || 4.5} ({dish.ratingCount || 0})
                </Text>
              </View>
            </View>
            
            <View style={styles.priceContainer}>
              <Text style={styles.currentPrice}>
                ₦{dish.price.toLocaleString('en-NG')}
              </Text>
              
              {dish.originalPrice && dish.originalPrice > dish.price && (
                <Text style={styles.originalPrice}>
                  ₦{dish.originalPrice.toLocaleString('en-NG')}
                </Text>
              )}
            </View>
          </View>
          
          {/* Cook Info */}
          <TouchableOpacity style={styles.cookContainer} onPress={goToCookProfile}>
            <Image 
              source={{ uri: cook.profileImage || 'https://via.placeholder.com/40' }} 
              style={styles.cookImage} 
            />
            
            <View style={styles.cookInfo}>
              <Text style={styles.cookName}>{cook.fullName}</Text>
              <Text style={styles.cookLocation}>
                {cook.location || 'Lagos, Nigeria'}
              </Text>
            </View>
            
            <Ionicons name="chevron-forward" size={20} color="#999" />
          </TouchableOpacity>
          
          {/* Description */}
          <View style={styles.sectionContainer}>
            <Text style={styles.sectionTitle}>Description</Text>
            <Text style={styles.description}>{dish.description}</Text>
          </View>
          
          {/* Preparation Time */}
          <View style={styles.detailRow}>
            <View style={styles.detailItem}>
              <Ionicons name="time-outline" size={20} color="#F57C00" />
              <View style={styles.detailTextContainer}>
                <Text style={styles.detailLabel}>Prep Time</Text>
                <Text style={styles.detailValue}>{dish.prepTime}</Text>
              </View>
            </View>
            
            {dish.hasVeganOption && (
              <View style={styles.detailItem}>
                <Ionicons name="leaf-outline" size={20} color="#4CAF50" />
                <View style={styles.detailTextContainer}>
                  <Text style={styles.detailLabel}>Dietary</Text>
                  <Text style={styles.detailValue}>Vegan Option</Text>
                </View>
              </View>
            )}
          </View>
          
          {/* Tags */}
          {dish.tags && dish.tags.length > 0 && (
            <View style={styles.sectionContainer}>
              <Text style={styles.sectionTitle}>Tags</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tagsContainer}>
                {dish.tags.map((tag, index) => (
                  <TouchableOpacity
                    key={index}
                    style={[
                      styles.tagButton,
                      selectedTag === tag && styles.selectedTagButton
                    ]}
                    onPress={() => setSelectedTag(selectedTag === tag ? null : tag)}
                  >
                    <Text
                      style={[
                        styles.tagText,
                        selectedTag === tag && styles.selectedTagText
                      ]}
                    >
                      {tag}
                    </Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>
            </View>
          )}
        </View>
      </ScrollView>
      
      {/* Bottom Action Bar */}
      <View style={styles.actionBar}>
        <View style={styles.quantitySelector}>
          <TouchableOpacity 
            style={styles.quantityButton}
            onPress={decreaseQuantity}
            disabled={quantity <= 1}
          >
            <Ionicons 
              name="remove" 
              size={20} 
              color={quantity <= 1 ? "#CCC" : "#333"} 
            />
          </TouchableOpacity>
          
          <Text style={styles.quantityText}>{quantity}</Text>
          
          <TouchableOpacity 
            style={styles.quantityButton}
            onPress={increaseQuantity}
          >
            <Ionicons name="add" size={20} color="#333" />
          </TouchableOpacity>
        </View>
        
        <View style={styles.orderButtons}>
          <EatsyButton
            label="Add to Cart"
            onPress={handleAddToCart}
            variant="outline"
            style={styles.cartButton}
          />
          
          <EatsyButton
            label={`Buy Now • ₦${calculateTotalPrice().toLocaleString('en-NG')}`}
            onPress={handleBuyNow}
            style={styles.buyButton}
          />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f8f8',
  },
  scrollView: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  loadingText: {
    marginTop: 10,
    color: '#666',
    fontSize: 16,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#fff',
  },
  errorText: {
    color: '#666',
    fontSize: 16,
    textAlign: 'center',
    marginTop: 10,
  },
  imageContainer: {
    width: '100%',
    height: 250,
    position: 'relative',
  },
  dishImage: {
    width: '100%',
    height: '100%',
  },
  backButton: {
    position: 'absolute',
    top: 15,
    left: 15,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  imageActions: {
    position: 'absolute',
    top: 15,
    right: 15,
    flexDirection: 'row',
  },
  actionButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 8,
  },
  infoContainer: {
    flex: 1,
    backgroundColor: '#fff',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    marginTop: -20,
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 100, // Extra padding for bottom action bar
  },
  headerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 15,
  },
  titleContainer: {
    flex: 1,
    marginRight: 10,
  },
  dishName: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  ratingText: {
    fontSize: 14,
    color: '#666',
    marginLeft: 4,
  },
  priceContainer: {
    alignItems: 'flex-end',
  },
  currentPrice: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#F57C00',
  },
  originalPrice: {
    fontSize: 14,
    color: '#999',
    textDecorationLine: 'line-through',
    marginTop: 2,
  },
  cookContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    backgroundColor: '#f9f9f9',
    borderRadius: 10,
    marginBottom: 20,
  },
  cookImage: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },
  cookInfo: {
    flex: 1,
    marginLeft: 12,
  },
  cookName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  cookLocation: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
  sectionContainer: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
  },
  description: {
    fontSize: 15,
    color: '#666',
    lineHeight: 22,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  detailItem: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f9f9f9',
    padding: 12,
    borderRadius: 10,
    marginRight: 8,
  },
  detailTextContainer: {
    marginLeft: 10,
  },
  detailLabel: {
    fontSize: 12,
    color: '#999',
  },
  detailValue: {
    fontSize: 14,
    fontWeight: '500',
    color: '#333',
  },
  tagsContainer: {
    flexDirection: 'row',
    paddingVertical: 5,
  },
  tagButton: {
    paddingHorizontal: 15,
    paddingVertical: 8,
    backgroundColor: '#f1f1f1',
    borderRadius: 20,
    marginRight: 10,
  },
  selectedTagButton: {
    backgroundColor: '#F57C00',
  },
  tagText: {
    fontSize: 14,
    color: '#666',
  },
  selectedTagText: {
    color: '#fff',
    fontWeight: '500',
  },
  actionBar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#eee',
    paddingHorizontal: 15,
    paddingVertical: 10,
    flexDirection: 'row',
    alignItems: 'center',
  },
  quantitySelector: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 4,
  },
  quantityButton: {
    width: 28,
    height: 28,
    justifyContent: 'center',
    alignItems: 'center',
  },
  quantityText: {
    fontSize: 16,
    fontWeight: '600',
    minWidth: 30,
    textAlign: 'center',
  },
  orderButtons: {
    flex: 1,
    flexDirection: 'row',
    marginLeft: 15,
  },
  cartButton: {
    flex: 0.4,
    marginRight: 8,
  },
  buyButton: {
    flex: 0.6,
  },
});

export default DishDetailsScreen;