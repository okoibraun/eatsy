import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
  Share
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { api } from '../services/api';
import EatsyButton from '../components/common/EatsyButton';

/**
 * CookProfileScreen - Displays the complete profile of a cook
 * 
 * @param {Object} route - Route parameters containing cookId
 * @param {Object} navigation - Navigation object
 * @returns {JSX.Element} The cook profile screen
 */
const CookProfileScreen = ({ route, navigation }) => {
  const { cookId } = route.params;
  const [profile, setProfile] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isFollowing, setIsFollowing] = useState(false);
  const [activeTab, setActiveTab] = useState('dishes'); // 'dishes' or 'reviews'

  useEffect(() => {
    fetchCookProfile();
  }, [cookId]);

  const fetchCookProfile = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await api.get(`/api/v1/social/cooks/${cookId}`);
      if (response.data && response.data.success) {
        setProfile(response.data.data);
        setIsFollowing(response.data.data.isFollowing);
      } else {
        setError('Failed to load cook profile');
      }
    } catch (err) {
      console.error('Error fetching cook profile:', err);
      setError('An error occurred while fetching cook profile');
    } finally {
      setIsLoading(false);
    }
  };

  const handleFollow = async () => {
    try {
      const response = await api.post(`/api/v1/social/cooks/${cookId}/follow`);
      if (response.data && response.data.success) {
        setIsFollowing(response.data.data.isFollowing);
      }
    } catch (err) {
      console.error('Error following/unfollowing cook:', err);
    }
  };

  const handleShare = async () => {
    if (!profile) return;

    try {
      await Share.share({
        message: `Check out ${profile.cook.fullName}'s delicious food on Eatsy Nigeria!`,
        url: `https://eatsy.ng/cooks/${cookId}`,
        title: `${profile.cook.fullName} on Eatsy Nigeria`,
      });
    } catch (error) {
      console.error('Error sharing profile:', error);
    }
  };

  const handleMessage = () => {
    // Navigate to chat screen with this cook
    navigation.navigate('Chat', { 
      recipientId: cookId, 
      recipientName: profile?.cook.fullName 
    });
  };

  const handleOrderNow = dishId => {
    // Navigate to dish details screen
    navigation.navigate('DishDetails', { dishId });
  };

  const renderDishItem = ({ item }) => (
    <View style={styles.dishCard}>
      <Image source={{ uri: item.dish.imageUrl }} style={styles.dishImage} />
      
      <View style={styles.dishInfo}>
        <Text style={styles.dishName} numberOfLines={2}>{item.dish.name}</Text>
        <Text style={styles.dishPrice}>₦{item.dish.price.toLocaleString('en-NG')}</Text>
        
        <View style={styles.dishMetrics}>
          <View style={styles.metricItem}>
            <Ionicons name="star" size={16} color="#FFD700" />
            <Text style={styles.metricText}>{item.dish.rating || 0}</Text>
          </View>
          
          <View style={styles.metricItem}>
            <Ionicons name="time-outline" size={16} color="#666" />
            <Text style={styles.metricText}>{item.dish.prepTime}</Text>
          </View>
          
          <View style={styles.metricItem}>
            <Ionicons name="heart" size={16} color={item.isLiked ? "#F44336" : "#666"} />
            <Text style={styles.metricText}>{item.likes}</Text>
          </View>
        </View>
        
        <EatsyButton
          label="Order Now"
          onPress={() => handleOrderNow(item.dish.id)}
          style={styles.orderButton}
          textStyle={styles.orderButtonText}
        />
      </View>
    </View>
  );

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#F57C00" />
        <Text style={styles.loadingText}>Loading cook profile...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.errorContainer}>
        <Ionicons name="alert-circle-outline" size={64} color="#F57C00" />
        <Text style={styles.errorText}>{error}</Text>
        <EatsyButton 
          label="Try Again" 
          onPress={fetchCookProfile}
          style={{ marginTop: 20 }}
        />
      </View>
    );
  }

  if (!profile) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>Profile not found</Text>
        <EatsyButton 
          label="Go Back" 
          onPress={() => navigation.goBack()}
          style={{ marginTop: 20 }}
        />
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      {/* Cover Photo */}
      <View style={styles.coverPhoto}>
        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Ionicons name="arrow-back" size={24} color="#FFF" />
        </TouchableOpacity>
      </View>
      
      {/* Profile Info */}
      <View style={styles.profileContainer}>
        <View style={styles.profileImageContainer}>
          <Image 
            source={{ uri: profile.cook.profileImage || 'https://via.placeholder.com/100' }} 
            style={styles.profileImage} 
          />
        </View>
        
        <Text style={styles.cookName}>{profile.cook.fullName}</Text>
        
        {profile.cook.cuisine && (
          <Text style={styles.cookCuisine}>{profile.cook.cuisine} Cuisine</Text>
        )}
        
        {profile.cook.location && (
          <View style={styles.locationContainer}>
            <Ionicons name="location-outline" size={16} color="#666" />
            <Text style={styles.locationText}>{profile.cook.location}</Text>
          </View>
        )}
        
        {/* Stats Section */}
        <View style={styles.statsContainer}>
          <View style={styles.statItem}>
            <Text style={styles.statValue}>{profile.stats.followersCount}</Text>
            <Text style={styles.statLabel}>Followers</Text>
          </View>
          
          <View style={styles.statDivider} />
          
          <View style={styles.statItem}>
            <Text style={styles.statValue}>{profile.stats.avgRating.toFixed(1)}</Text>
            <Text style={styles.statLabel}>Rating</Text>
          </View>
          
          <View style={styles.statDivider} />
          
          <View style={styles.statItem}>
            <Text style={styles.statValue}>{profile.stats.totalOrders}</Text>
            <Text style={styles.statLabel}>Orders</Text>
          </View>
        </View>
        
        {/* Action Buttons */}
        <View style={styles.actionButtonsContainer}>
          <EatsyButton
            label={isFollowing ? "Following" : "Follow"}
            onPress={handleFollow}
            variant={isFollowing ? "secondary" : "primary"}
            style={styles.actionButton}
          />
          
          <EatsyButton
            label="Message"
            onPress={handleMessage}
            variant="outline"
            style={styles.actionButton}
          />
          
          <TouchableOpacity style={styles.shareButton} onPress={handleShare}>
            <Ionicons name="share-social-outline" size={22} color="#666" />
          </TouchableOpacity>
        </View>
        
        {/* Bio Section */}
        {profile.cook.bio && (
          <View style={styles.bioContainer}>
            <Text style={styles.bioText}>{profile.cook.bio}</Text>
          </View>
        )}
        
        {/* Tabs Navigation */}
        <View style={styles.tabsContainer}>
          <TouchableOpacity
            style={[styles.tab, activeTab === 'dishes' && styles.activeTab]}
            onPress={() => setActiveTab('dishes')}
          >
            <Text style={[styles.tabText, activeTab === 'dishes' && styles.activeTabText]}>
              Dishes
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.tab, activeTab === 'reviews' && styles.activeTab]}
            onPress={() => setActiveTab('reviews')}
          >
            <Text style={[styles.tabText, activeTab === 'reviews' && styles.activeTabText]}>
              Reviews ({profile.stats.ratingCount})
            </Text>
          </TouchableOpacity>
        </View>
      </View>
      
      {/* Dishes List */}
      {activeTab === 'dishes' && (
        <View style={styles.dishesContainer}>
          {profile.dishes.length > 0 ? (
            <FlatList
              data={profile.dishes}
              renderItem={renderDishItem}
              keyExtractor={(item) => item.dish.id.toString()}
              scrollEnabled={false}
            />
          ) : (
            <View style={styles.emptyStateContainer}>
              <Ionicons name="restaurant-outline" size={64} color="#DDD" />
              <Text style={styles.emptyStateText}>No dishes available yet</Text>
            </View>
          )}
        </View>
      )}
      
      {/* Reviews Section - To be implemented */}
      {activeTab === 'reviews' && (
        <View style={styles.reviewsContainer}>
          <View style={styles.emptyStateContainer}>
            <Ionicons name="star-outline" size={64} color="#DDD" />
            <Text style={styles.emptyStateText}>No reviews available yet</Text>
          </View>
        </View>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f8f8',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  loadingText: {
    marginTop: 10,
    color: '#666',
    fontSize: 16,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#fff',
  },
  errorText: {
    color: '#666',
    fontSize: 16,
    textAlign: 'center',
    marginTop: 10,
  },
  coverPhoto: {
    width: '100%',
    height: 150,
    backgroundColor: '#F57C00',
    position: 'relative',
  },
  backButton: {
    position: 'absolute',
    top: 15,
    left: 15,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileContainer: {
    backgroundColor: '#fff',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    marginTop: -20,
    paddingTop: 0,
    paddingHorizontal: 20,
    alignItems: 'center',
  },
  profileImageContainer: {
    marginTop: -50,
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    borderWidth: 3,
    borderColor: '#fff',
  },
  cookName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginTop: 10,
  },
  cookCuisine: {
    fontSize: 16,
    color: '#F57C00',
    marginTop: 4,
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 5,
  },
  locationText: {
    fontSize: 14,
    color: '#666',
    marginLeft: 4,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    paddingVertical: 15,
    marginTop: 15,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: '#eee',
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
  },
  statValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  statLabel: {
    fontSize: 12,
    color: '#666',
    marginTop: 4,
  },
  statDivider: {
    width: 1,
    backgroundColor: '#eee',
  },
  actionButtonsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    width: '100%',
    marginTop: 15,
  },
  actionButton: {
    flex: 1,
    marginHorizontal: 5,
  },
  shareButton: {
    width: 46,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f1f1f1',
    borderRadius: 8,
    marginLeft: 5,
  },
  bioContainer: {
    width: '100%',
    marginTop: 15,
    padding: 15,
    backgroundColor: '#f9f9f9',
    borderRadius: 10,
  },
  bioText: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
  },
  tabsContainer: {
    flexDirection: 'row',
    width: '100%',
    marginTop: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  tab: {
    flex: 1,
    paddingVertical: 15,
    alignItems: 'center',
  },
  activeTab: {
    borderBottomWidth: 2,
    borderBottomColor: '#F57C00',
  },
  tabText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#999',
  },
  activeTabText: {
    color: '#F57C00',
  },
  dishesContainer: {
    padding: 15,
    backgroundColor: '#fff',
  },
  dishCard: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 10,
    marginBottom: 15,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  dishImage: {
    width: 120,
    height: 120,
    resizeMode: 'cover',
  },
  dishInfo: {
    flex: 1,
    padding: 12,
  },
  dishName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
  },
  dishPrice: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#F57C00',
    marginBottom: 8,
  },
  dishMetrics: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  metricItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 12,
  },
  metricText: {
    fontSize: 12,
    color: '#666',
    marginLeft: 3,
  },
  orderButton: {
    paddingVertical: 8,
    paddingHorizontal: 10,
  },
  orderButtonText: {
    fontSize: 14,
  },
  reviewsContainer: {
    padding: 15,
    backgroundColor: '#fff',
    minHeight: 200,
  },
  emptyStateContainer: {
    padding: 30,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyStateText: {
    fontSize: 16,
    color: '#999',
    marginTop: 10,
    textAlign: 'center',
  },
});

export default CookProfileScreen;