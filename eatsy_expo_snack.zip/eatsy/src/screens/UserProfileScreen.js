import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  Modal
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { api, authService } from '../services/api';
import EatsyButton from '../components/common/EatsyButton';
import EatsyInput from '../components/common/EatsyInput';

/**
 * UserProfileScreen - User's own profile with editing capabilities
 * 
 * @param {Object} navigation - Navigation object
 * @returns {JSX.Element} User profile screen
 */
const UserProfileScreen = ({ navigation }) => {
  const [userData, setUserData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [editMode, setEditMode] = useState(false);
  const [editedData, setEditedData] = useState({});
  const [isSaving, setIsSaving] = useState(false);
  const [showLogoutModal, setShowLogoutModal] = useState(false);

  useEffect(() => {
    fetchUserProfile();
  }, []);

  const fetchUserProfile = async () => {
    setIsLoading(true);
    setError(null);

    try {
      // Get the current user profile data
      const response = await api.get('/api/v1/auth/me');
      
      if (response.data && response.data.success) {
        const userData = response.data.data;
        setUserData(userData);
        setEditedData({
          fullName: userData.fullName || '',
          email: userData.email || '',
          phoneNumber: userData.phoneNumber || '',
          address: userData.address || '',
          bio: userData.bio || '',
          location: userData.location || '',
        });
      } else {
        setError('Failed to load profile data');
      }
    } catch (err) {
      console.error('Error fetching user profile:', err);
      setError('An error occurred while fetching profile data');
    } finally {
      setIsLoading(false);
    }
  };

  const handleEditProfile = () => {
    setEditMode(true);
  };

  const handleCancelEdit = () => {
    // Reset edited data to original values
    if (userData) {
      setEditedData({
        fullName: userData.fullName || '',
        email: userData.email || '',
        phoneNumber: userData.phoneNumber || '',
        address: userData.address || '',
        bio: userData.bio || '',
        location: userData.location || '',
      });
    }
    setEditMode(false);
  };

  const handleSaveProfile = async () => {
    setIsSaving(true);

    try {
      // Validate email format
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (editedData.email && !emailRegex.test(editedData.email)) {
        Alert.alert('Invalid Email', 'Please enter a valid email address');
        setIsSaving(false);
        return;
      }

      // Validate Nigerian phone number if provided
      const phoneRegex = /^(\+234|0)[0-9]{10,11}$/;
      if (editedData.phoneNumber && !phoneRegex.test(editedData.phoneNumber)) {
        Alert.alert(
          'Invalid Phone Number', 
          'Please enter a valid Nigerian phone number (e.g., +2348012345678 or 08012345678)'
        );
        setIsSaving(false);
        return;
      }

      const response = await api.put('/api/v1/auth/profile', editedData);
      
      if (response.data && response.data.success) {
        setUserData(response.data.data);
        setEditMode(false);
        Alert.alert('Success', 'Profile updated successfully');
      } else {
        Alert.alert('Error', 'Failed to update profile');
      }
    } catch (err) {
      console.error('Error updating profile:', err);
      Alert.alert(
        'Error',
        err.response?.data?.error?.message || 'An error occurred while updating profile'
      );
    } finally {
      setIsSaving(false);
    }
  };

  const handleLogout = async () => {
    setShowLogoutModal(false);
    
    try {
      await authService.logout();
      
      // Navigate to the login screen
      navigation.reset({
        index: 0,
        routes: [{ name: 'Login' }],
      });
    } catch (err) {
      console.error('Error logging out:', err);
      Alert.alert('Error', 'Failed to log out. Please try again.');
    }
  };

  const navigateToOrderHistory = () => {
    navigation.navigate('OrderHistory');
  };

  const navigateToSavedDishes = () => {
    navigation.navigate('SavedDishes');
  };

  const navigateToFavoriteCooks = () => {
    navigation.navigate('FavoriteCooks');
  };

  const navigateToPaymentMethods = () => {
    navigation.navigate('PaymentMethods');
  };

  const navigateToDeliveryAddresses = () => {
    navigation.navigate('DeliveryAddresses');
  };

  const navigateToHelpSupport = () => {
    navigation.navigate('HelpSupport');
  };

  const navigateToSettings = () => {
    navigation.navigate('Settings');
  };

  const handleInputChange = (field, value) => {
    setEditedData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#F57C00" />
        <Text style={styles.loadingText}>Loading profile...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.errorContainer}>
        <Ionicons name="alert-circle-outline" size={64} color="#F57C00" />
        <Text style={styles.errorText}>{error}</Text>
        <EatsyButton 
          label="Try Again" 
          onPress={fetchUserProfile}
          style={{ marginTop: 20 }}
        />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Profile Header */}
        <View style={styles.profileHeader}>
          <View style={styles.coverPhoto}>
            {!editMode && (
              <TouchableOpacity 
                style={styles.settingsButton}
                onPress={navigateToSettings}
              >
                <Ionicons name="settings-outline" size={24} color="#FFF" />
              </TouchableOpacity>
            )}
          </View>
          
          <View style={styles.profileImageContainer}>
            <Image 
              source={{ 
                uri: userData?.profileImage || 'https://via.placeholder.com/100'
              }} 
              style={styles.profileImage} 
            />
            {editMode && (
              <TouchableOpacity style={styles.editProfileImageButton}>
                <Ionicons name="camera" size={20} color="#FFF" />
              </TouchableOpacity>
            )}
          </View>
          
          <View style={styles.profileInfo}>
            {!editMode ? (
              <>
                <Text style={styles.userName}>{userData?.fullName || 'User Name'}</Text>
                <Text style={styles.userType}>
                  {userData?.userType === 'cook' ? 'Home Cook' : 'Customer'}
                </Text>
                {userData?.location && (
                  <Text style={styles.userLocation}>
                    <Ionicons name="location-outline" size={16} color="#666" /> {userData.location}
                  </Text>
                )}
                <View style={styles.profileActions}>
                  <EatsyButton
                    label="Edit Profile"
                    onPress={handleEditProfile}
                    variant="outline"
                    style={styles.editButton}
                  />
                </View>
              </>
            ) : (
              <View style={styles.editForm}>
                <EatsyInput
                  label="Full Name"
                  value={editedData.fullName}
                  onChangeText={(value) => handleInputChange('fullName', value)}
                  placeholder="Enter your full name"
                  required
                />
                
                <EatsyInput
                  label="Email Address"
                  value={editedData.email}
                  onChangeText={(value) => handleInputChange('email', value)}
                  placeholder="Enter your email"
                  keyboardType="email-address"
                  autoCapitalize="none"
                />
                
                <EatsyInput
                  label="Phone Number"
                  value={editedData.phoneNumber}
                  onChangeText={(value) => handleInputChange('phoneNumber', value)}
                  placeholder="e.g., +2348012345678"
                  keyboardType="phone-pad"
                />
                
                <EatsyInput
                  label="Location"
                  value={editedData.location}
                  onChangeText={(value) => handleInputChange('location', value)}
                  placeholder="e.g., Lagos, Nigeria"
                />
                
                <EatsyInput
                  label="Address"
                  value={editedData.address}
                  onChangeText={(value) => handleInputChange('address', value)}
                  placeholder="Enter your address"
                  multiline
                  style={{ height: 80 }}
                />
                
                <EatsyInput
                  label="Bio"
                  value={editedData.bio}
                  onChangeText={(value) => handleInputChange('bio', value)}
                  placeholder="Tell us about yourself"
                  multiline
                  style={{ height: 100 }}
                />
                
                <View style={styles.editActions}>
                  <EatsyButton 
                    label="Cancel" 
                    onPress={handleCancelEdit} 
                    variant="outline"
                    style={styles.cancelButton}
                  />
                  <EatsyButton 
                    label="Save" 
                    onPress={handleSaveProfile}
                    isLoading={isSaving}
                    style={styles.saveButton}
                  />
                </View>
              </View>
            )}
          </View>
        </View>
        
        {/* Profile Menu */}
        {!editMode && (
          <View style={styles.menuContainer}>
            <TouchableOpacity 
              style={styles.menuItem}
              onPress={navigateToOrderHistory}
            >
              <View style={styles.menuIcon}>
                <Ionicons name="receipt-outline" size={22} color="#333" />
              </View>
              <View style={styles.menuContent}>
                <Text style={styles.menuText}>Order History</Text>
                <Ionicons name="chevron-forward" size={20} color="#ccc" />
              </View>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.menuItem}
              onPress={navigateToSavedDishes}
            >
              <View style={styles.menuIcon}>
                <Ionicons name="bookmark-outline" size={22} color="#333" />
              </View>
              <View style={styles.menuContent}>
                <Text style={styles.menuText}>Saved Dishes</Text>
                <Ionicons name="chevron-forward" size={20} color="#ccc" />
              </View>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.menuItem}
              onPress={navigateToFavoriteCooks}
            >
              <View style={styles.menuIcon}>
                <Ionicons name="heart-outline" size={22} color="#333" />
              </View>
              <View style={styles.menuContent}>
                <Text style={styles.menuText}>Favorite Cooks</Text>
                <Ionicons name="chevron-forward" size={20} color="#ccc" />
              </View>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.menuItem}
              onPress={navigateToPaymentMethods}
            >
              <View style={styles.menuIcon}>
                <Ionicons name="card-outline" size={22} color="#333" />
              </View>
              <View style={styles.menuContent}>
                <Text style={styles.menuText}>Payment Methods</Text>
                <Ionicons name="chevron-forward" size={20} color="#ccc" />
              </View>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.menuItem}
              onPress={navigateToDeliveryAddresses}
            >
              <View style={styles.menuIcon}>
                <Ionicons name="location-outline" size={22} color="#333" />
              </View>
              <View style={styles.menuContent}>
                <Text style={styles.menuText}>Delivery Addresses</Text>
                <Ionicons name="chevron-forward" size={20} color="#ccc" />
              </View>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.menuItem}
              onPress={navigateToHelpSupport}
            >
              <View style={styles.menuIcon}>
                <Ionicons name="help-circle-outline" size={22} color="#333" />
              </View>
              <View style={styles.menuContent}>
                <Text style={styles.menuText}>Help & Support</Text>
                <Ionicons name="chevron-forward" size={20} color="#ccc" />
              </View>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.menuItem}
              onPress={() => setShowLogoutModal(true)}
            >
              <View style={styles.menuIcon}>
                <Ionicons name="log-out-outline" size={22} color="#D32F2F" />
              </View>
              <View style={styles.menuContent}>
                <Text style={[styles.menuText, { color: '#D32F2F' }]}>Logout</Text>
                <Ionicons name="chevron-forward" size={20} color="#ccc" />
              </View>
            </TouchableOpacity>
          </View>
        )}
        
        {!editMode && (
          <Text style={styles.versionText}>Eatsy Nigeria v1.0.0</Text>
        )}
      </ScrollView>
      
      {/* Logout Confirmation Modal */}
      <Modal
        visible={showLogoutModal}
        animationType="fade"
        transparent={true}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <Text style={styles.modalTitle}>Logout</Text>
            <Text style={styles.modalText}>Are you sure you want to log out?</Text>
            
            <View style={styles.modalActions}>
              <TouchableOpacity 
                style={[styles.modalButton, styles.cancelModalButton]}
                onPress={() => setShowLogoutModal(false)}
              >
                <Text style={styles.cancelModalButtonText}>Cancel</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={[styles.modalButton, styles.logoutModalButton]}
                onPress={handleLogout}
              >
                <Text style={styles.logoutModalButtonText}>Logout</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f8f8',
  },
  scrollContent: {
    flexGrow: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  loadingText: {
    marginTop: 10,
    color: '#666',
    fontSize: 16,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#fff',
  },
  errorText: {
    color: '#666',
    fontSize: 16,
    textAlign: 'center',
    marginTop: 10,
  },
  profileHeader: {
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
    marginBottom: 15,
  },
  coverPhoto: {
    width: '100%',
    height: 120,
    backgroundColor: '#F57C00',
    position: 'relative',
  },
  settingsButton: {
    position: 'absolute',
    top: 15,
    right: 15,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileImageContainer: {
    alignItems: 'center',
    marginTop: -50,
    position: 'relative',
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    borderWidth: 3,
    borderColor: '#fff',
  },
  editProfileImageButton: {
    position: 'absolute',
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileInfo: {
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  userName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginTop: 10,
  },
  userType: {
    fontSize: 16,
    color: '#F57C00',
    marginTop: 4,
  },
  userLocation: {
    fontSize: 14,
    color: '#666',
    marginTop: 5,
    flexDirection: 'row',
    alignItems: 'center',
  },
  profileActions: {
    flexDirection: 'row',
    marginTop: 15,
  },
  editButton: {
    minWidth: 140,
  },
  editForm: {
    width: '100%',
    marginTop: 20,
  },
  editActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  cancelButton: {
    flex: 1,
    marginRight: 10,
  },
  saveButton: {
    flex: 1,
    marginLeft: 10,
  },
  menuContainer: {
    backgroundColor: '#fff',
    borderRadius: 10,
    marginHorizontal: 15,
    marginBottom: 20,
    overflow: 'hidden',
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  menuIcon: {
    width: 50,
    alignItems: 'center',
  },
  menuContent: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingRight: 15,
  },
  menuText: {
    fontSize: 16,
    color: '#333',
  },
  versionText: {
    textAlign: 'center',
    color: '#999',
    fontSize: 12,
    marginBottom: 30,
  },
  // Modal styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    width: '80%',
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 20,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 15,
  },
  modalText: {
    fontSize: 16,
    color: '#666',
    marginBottom: 20,
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  modalButton: {
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 5,
    marginLeft: 10,
  },
  cancelModalButton: {
    backgroundColor: '#f1f1f1',
  },
  cancelModalButtonText: {
    color: '#333',
    fontWeight: '500',
  },
  logoutModalButton: {
    backgroundColor: '#D32F2F',
  },
  logoutModalButtonText: {
    color: '#fff',
    fontWeight: '500',
  },
});

export default UserProfileScreen;