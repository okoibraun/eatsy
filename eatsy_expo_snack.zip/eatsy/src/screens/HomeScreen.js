import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  FlatList,
  RefreshControl
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { authService } from '../services/api';

// Placeholder data for stories
const STORIES_DATA = [
  { id: '1', name: 'Folake', image: 'https://via.placeholder.com/50', hasNewStory: true },
  { id: '2', name: 'Chidi', image: 'https://via.placeholder.com/50', hasNewStory: true },
  { id: '3', name: 'Amina', image: 'https://via.placeholder.com/50', hasNewStory: false },
  { id: '4', name: 'Emeka', image: 'https://via.placeholder.com/50', hasNewStory: true },
  { id: '5', name: 'Bisi', image: 'https://via.placeholder.com/50', hasNewStory: false },
];

// Placeholder data for food items
const FOOD_DATA = [
  {
    id: '1',
    title: 'Jollof Rice with Chicken',
    cookName: 'Mama Folake',
    image: 'https://via.placeholder.com/150',
    price: '₦1,500',
    rating: 4.7,
    distance: '1.2km',
    likes: 132,
    comments: 24,
  },
  {
    id: '2',
    title: 'Egusi Soup with Fufu',
    cookName: 'Chef James',
    image: 'https://via.placeholder.com/150',
    price: '₦2,000',
    rating: 4.9,
    distance: '0.8km',
    likes: 201,
    comments: 46,
  },
  {
    id: '3',
    title: 'Suya Platter',
    cookName: 'Mallam Hassan',
    image: 'https://via.placeholder.com/150',
    price: '₦1,800',
    rating: 4.5,
    distance: '2.3km',
    likes: 98,
    comments: 17,
  },
  {
    id: '4',
    title: 'Pepper Soup',
    cookName: 'Auntie Joy',
    image: 'https://via.placeholder.com/150',
    price: '₦1,200',
    rating: 4.6,
    distance: '1.5km',
    likes: 85,
    comments: 12,
  },
];

const HomeScreen = () => {
  const [userData, setUserData] = useState(null);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    fetchUserData();
  }, []);

  const fetchUserData = async () => {
    try {
      const data = await authService.getUserData();
      setUserData(data);
    } catch (error) {
      console.error('Error fetching user data:', error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await fetchUserData();
    // Simulating network request
    setTimeout(() => {
      setRefreshing(false);
    }, 1000);
  };

  const renderStoryItem = ({ item }) => (
    <TouchableOpacity style={styles.storyContainer}>
      <View style={[
        styles.storyImageContainer,
        item.hasNewStory ? styles.storyImageContainerActive : null
      ]}>
        <Image source={{ uri: item.image }} style={styles.storyImage} />
      </View>
      <Text style={styles.storyName} numberOfLines={1}>
        {item.name}
      </Text>
    </TouchableOpacity>
  );

  const renderFoodItem = ({ item }) => (
    <View style={styles.foodCard}>
      <Image source={{ uri: item.image }} style={styles.foodImage} />
      
      <View style={styles.foodDetailsContainer}>
        <View style={styles.foodHeaderContainer}>
          <Text style={styles.foodTitle} numberOfLines={2}>{item.title}</Text>
          <Text style={styles.foodPrice}>{item.price}</Text>
        </View>
        
        <Text style={styles.cookName}>By {item.cookName}</Text>
        
        <View style={styles.foodMetaContainer}>
          <View style={styles.ratingContainer}>
            <Ionicons name="star" size={16} color="#FFD700" />
            <Text style={styles.ratingText}>{item.rating}</Text>
          </View>
          
          <View style={styles.distanceContainer}>
            <Ionicons name="location" size={16} color="#F57C00" />
            <Text style={styles.distanceText}>{item.distance}</Text>
          </View>
        </View>
        
        <View style={styles.foodActionsContainer}>
          <TouchableOpacity style={styles.actionButton}>
            <Ionicons name="heart-outline" size={22} color="#666" />
            <Text style={styles.actionText}>{item.likes}</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.actionButton}>
            <Ionicons name="chatbubble-outline" size={22} color="#666" />
            <Text style={styles.actionText}>{item.comments}</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.actionButton}>
            <Ionicons name="bookmark-outline" size={22} color="#666" />
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.orderButton}>
            <Text style={styles.orderButtonText}>Order</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );

  return (
    <ScrollView 
      style={styles.container}
      refreshControl={
        <RefreshControl
          refreshing={refreshing}
          onRefresh={onRefresh}
          colors={['#F57C00']}
        />
      }
    >
      {/* Header Section with Greeting */}
      <View style={styles.headerContainer}>
        <View>
          <Text style={styles.welcomeText}>
            Hello, {userData?.fullName?.split(' ')[0] || 'there'}!
          </Text>
          <Text style={styles.locationText}>
            <Ionicons name="location" size={16} color="#F57C00" />
            Lagos, Nigeria
          </Text>
        </View>
        <View style={styles.headerActions}>
          <TouchableOpacity style={styles.iconButton}>
            <Ionicons name="notifications-outline" size={24} color="#333" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.iconButton}>
            <Ionicons name="cart-outline" size={24} color="#333" />
          </TouchableOpacity>
        </View>
      </View>

      {/* Search Bar */}
      <TouchableOpacity style={styles.searchBar}>
        <Ionicons name="search" size={20} color="#666" />
        <Text style={styles.searchText}>Find delicious meals...</Text>
      </TouchableOpacity>

      {/* Stories Section */}
      <View style={styles.sectionContainer}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Stories</Text>
          <TouchableOpacity>
            <Text style={styles.seeAllText}>See All</Text>
          </TouchableOpacity>
        </View>
        <FlatList
          data={STORIES_DATA}
          renderItem={renderStoryItem}
          keyExtractor={item => item.id}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.storiesListContainer}
        />
      </View>

      {/* Categories Section */}
      <View style={styles.sectionContainer}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Categories</Text>
          <TouchableOpacity>
            <Text style={styles.seeAllText}>See All</Text>
          </TouchableOpacity>
        </View>
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.categoriesContainer}
        >
          <TouchableOpacity style={styles.categoryButton}>
            <Text style={styles.categoryText}>All</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.categoryButton, styles.categoryButtonActive]}>
            <Text style={[styles.categoryText, styles.categoryTextActive]}>Jollof Rice</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.categoryButton}>
            <Text style={styles.categoryText}>Swallow</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.categoryButton}>
            <Text style={styles.categoryText}>Soups</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.categoryButton}>
            <Text style={styles.categoryText}>Proteins</Text>
          </TouchableOpacity>
        </ScrollView>
      </View>

      {/* Trending Food Section */}
      <View style={styles.sectionContainer}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Trending Today</Text>
          <TouchableOpacity>
            <Text style={styles.seeAllText}>See All</Text>
          </TouchableOpacity>
        </View>
        <FlatList
          data={FOOD_DATA}
          renderItem={renderFoodItem}
          keyExtractor={item => item.id}
          scrollEnabled={false}
        />
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f8f8',
  },
  headerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 20,
    paddingBottom: 10,
    backgroundColor: '#fff',
  },
  welcomeText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  locationText: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  headerActions: {
    flexDirection: 'row',
  },
  iconButton: {
    padding: 8,
    marginLeft: 8,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    marginHorizontal: 16,
    marginVertical: 16,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#eee',
  },
  searchText: {
    marginLeft: 10,
    color: '#999',
    fontSize: 16,
  },
  sectionContainer: {
    marginBottom: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    marginBottom: 10,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  seeAllText: {
    fontSize: 14,
    color: '#F57C00',
  },
  storiesListContainer: {
    paddingHorizontal: 16,
  },
  storyContainer: {
    alignItems: 'center',
    marginRight: 16,
    width: 70,
  },
  storyImageContainer: {
    width: 60,
    height: 60,
    borderRadius: 30,
    padding: 2,
    borderWidth: 1,
    borderColor: '#ddd',
    marginBottom: 5,
  },
  storyImageContainerActive: {
    borderWidth: 2,
    borderColor: '#F57C00',
  },
  storyImage: {
    width: '100%',
    height: '100%',
    borderRadius: 28,
  },
  storyName: {
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
  },
  categoriesContainer: {
    paddingHorizontal: 16,
    paddingBottom: 5,
  },
  categoryButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#fff',
    marginRight: 12,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  categoryButtonActive: {
    backgroundColor: '#F57C00',
    borderColor: '#F57C00',
  },
  categoryText: {
    fontSize: 14,
    color: '#666',
  },
  categoryTextActive: {
    color: '#fff',
    fontWeight: '500',
  },
  foodCard: {
    backgroundColor: '#fff',
    borderRadius: 10,
    marginHorizontal: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
    overflow: 'hidden',
  },
  foodImage: {
    width: '100%',
    height: 180,
    resizeMode: 'cover',
  },
  foodDetailsContainer: {
    padding: 12,
  },
  foodHeaderContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 5,
  },
  foodTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    flex: 1,
    marginRight: 8,
  },
  foodPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#F57C00',
  },
  cookName: {
    fontSize: 14,
    color: '#666',
    marginBottom: 8,
  },
  foodMetaContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 16,
  },
  ratingText: {
    marginLeft: 4,
    fontSize: 14,
    color: '#666',
  },
  distanceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  distanceText: {
    marginLeft: 4,
    fontSize: 14,
    color: '#666',
  },
  foodActionsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 5,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  actionText: {
    marginLeft: 4,
    fontSize: 14,
    color: '#666',
  },
  orderButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: '#F57C00',
    borderRadius: 6,
  },
  orderButtonText: {
    color: '#fff',
    fontWeight: '500',
  },
});

export default HomeScreen;