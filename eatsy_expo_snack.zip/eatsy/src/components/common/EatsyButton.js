import React from 'react';
import { TouchableOpacity, Text, StyleSheet, ActivityIndicator } from 'react-native';

/**
 * EatsyButton - Custom button component for the Eatsy Nigeria application
 * 
 * @param {string} label - Text to display on the button
 * @param {function} onPress - Function to call when button is pressed
 * @param {boolean} isLoading - Whether to show loading indicator
 * @param {boolean} disabled - Whether button is disabled
 * @param {string} variant - Button variant (primary, secondary, outline, danger)
 * @param {object} style - Additional styles to apply to button
 * @param {object} textStyle - Additional styles to apply to button text
 * @returns {JSX.Element} Button component
 */
const EatsyButton = ({
  label,
  onPress,
  isLoading = false,
  disabled = false,
  variant = 'primary',
  style,
  textStyle,
}) => {
  // Determine button styling based on variant
  const buttonStyles = [styles.button];
  const labelStyles = [styles.label];

  // Apply variant styling
  switch (variant) {
    case 'primary':
      buttonStyles.push(styles.primaryButton);
      labelStyles.push(styles.primaryLabel);
      break;
    case 'secondary':
      buttonStyles.push(styles.secondaryButton);
      labelStyles.push(styles.secondaryLabel);
      break;
    case 'outline':
      buttonStyles.push(styles.outlineButton);
      labelStyles.push(styles.outlineLabel);
      break;
    case 'danger':
      buttonStyles.push(styles.dangerButton);
      labelStyles.push(styles.dangerLabel);
      break;
  }

  // Apply disabled styling
  if (disabled || isLoading) {
    buttonStyles.push(styles.disabledButton);
  }

  // Apply custom styles
  if (style) {
    buttonStyles.push(style);
  }
  
  if (textStyle) {
    labelStyles.push(textStyle);
  }

  return (
    <TouchableOpacity
      style={buttonStyles}
      onPress={onPress}
      disabled={disabled || isLoading}
      activeOpacity={0.8}
    >
      {isLoading ? (
        <ActivityIndicator
          size="small"
          color={variant === 'outline' ? '#F57C00' : '#FFFFFF'}
        />
      ) : (
        <Text style={labelStyles}>{label}</Text>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  button: {
    paddingVertical: 15,
    paddingHorizontal: 20,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    minHeight: 50,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
  },
  // Primary variant (orange)
  primaryButton: {
    backgroundColor: '#F57C00',
  },
  primaryLabel: {
    color: '#FFFFFF',
  },
  // Secondary variant (light orange)
  secondaryButton: {
    backgroundColor: '#FFE0B2',
  },
  secondaryLabel: {
    color: '#F57C00',
  },
  // Outline variant
  outlineButton: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: '#F57C00',
  },
  outlineLabel: {
    color: '#F57C00',
  },
  // Danger variant
  dangerButton: {
    backgroundColor: '#D32F2F',
  },
  dangerLabel: {
    color: '#FFFFFF',
  },
  // Disabled state
  disabledButton: {
    opacity: 0.6,
  },
});

export default EatsyButton;