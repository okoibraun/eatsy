import React from 'react';
import { TouchableOpacity, Text, StyleSheet, View, Image } from 'react-native';

/**
 * SocialLoginButton - Social media login button component
 * 
 * @param {string} provider - Social media provider (google, facebook, apple)
 * @param {function} onPress - Function to call when button is pressed
 * @param {object} style - Additional styles to apply
 * @returns {JSX.Element} Social login button component
 */
const SocialLoginButton = ({
  provider,
  onPress,
  style
}) => {
  // Define provider-specific properties
  const getProviderConfig = () => {
    switch (provider.toLowerCase()) {
      case 'google':
        return {
          label: 'Continue with Google',
          icon: require('../../assets/icons/google-icon.svg'), // You'll need to add these icons
          backgroundColor: '#FFFFFF',
          textColor: '#333333',
          borderColor: '#DADCE0'
        };
      case 'facebook':
        return {
          label: 'Continue with Facebook',
          icon: require('../../assets/icons/facebook-icon.svg'),
          backgroundColor: '#1877F2',
          textColor: '#FFFFFF',
          borderColor: '#1877F2'
        };
      case 'apple':
        return {
          label: 'Continue with Apple',
          icon: require('../../assets/icons/apple-icon.svg'),
          backgroundColor: '#000000',
          textColor: '#FFFFFF',
          borderColor: '#000000'
        };
      default:
        return {
          label: `Continue with ${provider}`,
          icon: null,
          backgroundColor: '#EEEEEE',
          textColor: '#333333',
          borderColor: '#CCCCCC'
        };
    }
  };

  const config = getProviderConfig();

  return (
    <TouchableOpacity
      style={[
        styles.button,
        {
          backgroundColor: config.backgroundColor,
          borderColor: config.borderColor
        },
        style
      ]}
      onPress={onPress}
      activeOpacity={0.7}
    >
      {config.icon && (
        <Image
          source={config.icon}
          style={styles.icon}
          resizeMode="contain"
        />
      )}
      <Text
        style={[
          styles.label,
          { color: config.textColor }
        ]}
      >
        {config.label}
      </Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    borderWidth: 1,
    marginVertical: 8,
  },
  icon: {
    width: 24,
    height: 24,
    marginRight: 12,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
  },
});

export default SocialLoginButton;